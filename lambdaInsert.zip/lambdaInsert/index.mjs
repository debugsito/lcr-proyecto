import AWS from "aws-sdk";
export const handler = async (event) => {
  const records = event.Records;

  for (const record of records) {
    const message = JSON.parse(record.body);
    const params = {
      TableName: 'miTabla',
      Item: {
        id: { S: message.id },
        timestamp: { N: message.timestamp },
        input: { S: message.input },
        output: { S: message.output },
      },
    };
    
    const dynamodb = new AWS.DynamoDB();
    await dynamodb.putItem(params).promise();
  }
};